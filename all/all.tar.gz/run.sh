./src/mainSigmod2014 $1 $2
