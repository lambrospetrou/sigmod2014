g++  lplibs/LPBitset.cpp lplibs/LPThreadpool.cpp lplibs/LPSparseArrayLong.cpp lplibs/LPSparseBitset.cpp lplibs/LPDisjointSetForest.h main.cpp -lpthread -o mainSigmod2014 -w
