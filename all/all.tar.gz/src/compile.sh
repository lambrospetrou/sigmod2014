g++ -O3 lplibs/LPThreadpool.cpp lplibs/TopKCloseness.cpp lplibs/LPSparseArrayGeneric.h lplibs/LPSparseBitset.cpp lplibs/LPBitset.cpp  main.cpp -lpthread -o mainSigmod2014 -w
