#g++ -g lplibs/LPBitset.cpp lplibs/LPThreadpool.cpp main.cpp -lpthread -o mainSigmod2014 -w 
g++  lplibs/LPBitset.cpp lplibs/LPThreadpool.cpp lplibs/LPDisjointSetForest.h main.cpp -lpthread -o mainSigmod2014 -w 
