/*
 * StructsGlobals.h
 *
 *  Created on: Apr 2, 2014
 *      Author: lambros
 */

#ifndef STRUCTSGLOBALS_H_
#define STRUCTSGLOBALS_H_





#endif /* STRUCTSGLOBALS_H_ */
